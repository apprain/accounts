<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Accounts_Helpers_Statement extends Component_Accounts_Helpers_PDF_FPDF 
{
    public $b = 0;
	public $cellheight = 6;
	public $border = 0;
	public $rowcount = 5;

	public $fontFamily = 'Helvetica';
	public $TxnRowCnt = 1;
	
	
	public function conditionByDuration($type=null,$accountno,$fromeDate,$toDate){
		if($type == 'receivedinvoice'){
			$condition = "(creditaccount='{$accountno}') and date(entrydate) between '{$fromeDate}' and '{$toDate}' ORDER BY id ASC";
		}
		elseif($type == 'paymentinvoice'){
			$condition = "(debitaccount='{$accountno}') and date(entrydate) between '{$fromeDate}' and '{$toDate}' ORDER BY id ASC";
		}
		else{
			$condition = "(debitaccount='{$accountno}' OR creditaccount='{$accountno}') and date(entrydate) between '{$fromeDate}' and '{$toDate}' ORDER BY id ASC";		
		}
		
		return $condition;
	}
	
	public function TransactionRows($accountno,$fromeDate,$toDate){

		$condition = $this->conditionByDuration($this->getStatementType(),$accountno,$fromeDate,$toDate);
		$list = App::Model('Accentry')->findAll($condition);
		
		return $list['data'];
	}
	
	public function TransactionSum($accountno,$fromeDate,$toDate){

		$condition = $this->conditionByDuration($this->getStatementType(),$accountno,$fromeDate,$toDate);
		$list = App::Model('Accentry')->find($condition,null,'sum(amount) as total');
		return $list['total'];
	}
	
	public function Generate($fromeDate=null,$toDate=null){
		
		$list = $this->setStatementType($this->getStatementType())->TransactionRows($this->getAccountNo(),$fromeDate,$toDate);
	
		$data = array();
		$data['transaction'] = $list;
		
		if($this->getStatementType()=='statement'){
			$data['currentbalance'] = App::Component('Accounts')->Helper('Data')->CurrentBalance($this->getAccountNo());
		}
		elseif($this->getStatementType()=='invoice'){
			$TCR = $this->setStatementType('receivedinvoice')->TransactionSum($this->getAccountNo(),$fromeDate,$toDate);
			$TDR = $this->setStatementType('paymentinvoice')->TransactionSum($this->getAccountNo(),$fromeDate,$toDate);
			$data['total'] = $TCR-$TDR;
			$this->setStatementType('invoice');
		}
		else {
			$data['total'] = $this->setStatementType($this->getStatementType())->TransactionSum($this->getAccountNo(),$fromeDate,$toDate);
		}
		
		return $data;		
	}
	
	public function formatRow($accountno,$row){
	
		$List = Array();
		
		$List['id'] = $row['id'];
		$List['date'] = App::Helper("Date")->dateFormated($row['entrydate']);
		
		$EntryCode = App::InformationSet('entrycode')->findByCode($row['code']);
		$description = !empty($row['fullremark'])? $row['fullremark'] : $EntryCode['name'];    
		$List['description'] = !empty($description) ? $description : $row['code'];	
		
		$List['currency'] = App::Config()->Setting('currency','BDT');				
		$List['amount'] = App::Component('Accounts')->Helper('Data')->numberformate($row['amount']);
		$List['direction']='';
        if($this->getStatementType() == 'statement' || $this->getStatementType() == 'invoice'){
			$List['direction'] = App::Component('Accounts')->Helper('Data')->txnDirection($row,$accountno);	
			$List['direction'] = ($List['direction'] == 'CR') ? 'DR' : 'CR';
		}
		$List['corracc'] = ($row['debitaccount']!=$accountno) ? $row['debitaccount'] : $row['creditaccount'];
		$List['bgcolor'] = ($this->TxnRowCnt%2==1) ? '#EEE' : '#FFF';

		
		$this->TxnRowCnt++;
		
		return  $List;
	}
	
	public function Title($pm=''){
		$t = array('statement'=>'STATEMENT','invoice'=>'INVOICE','paymentinvoice'=>'PAYMENT INVOICE','receivedinvoice'=>'RECEIVED INVOICE');
		
		return isset($t[$pm]) ? $t[$pm] : $t;
	}
	
	
	public function Download($fromeDate=null,$toDate=null){
		
		$Account = App::Model('Accchart')->findByNo($this->getAccountNo());
		$List = $this->Generate($fromeDate,$toDate);	
		$this->AddNewPage();
		
		$TopHeader = array();
		$TopHeader[] = array(App::Config()->Setting('site_title'));
		$TopHeader[] = array($Account['name']);
		$TopHeader[] = array('Date',App::Helper('Date')->dateFormated(null,'long'));
		$TopHeader[] = array('Date Range',App::Helper('Date')->dateFormated($fromeDate) . ' to ' .  App::Helper('Date')->dateFormated($toDate));
		
		if(isset($List['currentbalance'])){
			$TopHeader[] = array('Current Balance',App::Component('Accounts')->Helper('Data')->numberformate($List['currentbalance']));
		}
		
		foreach($TopHeader as $row){
			if( sizeof($row) == 1){				
				$this->Cell(103,$this->cellheight ,$row[0],$this->border,1,'L');
			}
			else{
				$this->Cell(40,$this->cellheight ,$row[0],$this->border,0,'L');
				$this->Cell(3,$this->cellheight ,':',$this->border,0,'C');
				$this->Cell(60,$this->cellheight ,$row[1],$this->border,1,'L');
			}
		}
		
		$this->Ln($this->cellheight);
		
		$this->SetFillColor(220,220,220);
		$this->tableHeader();
		
		foreach($List['transaction'] as $r){
	
			$row = $this->formatRow($this->getAccountNo(),$r);

			if($this->rowcount%35 == 0 and $this->rowcount != 0){
				
				$this->Cell(30,$this->cellheight ,$row['date'],'LRB',0,'L',0);
				$this->Cell(90,$this->cellheight ,$row['description'],'LRB',0,'L');
				$this->Cell(10,$this->cellheight ,$row['currency'],'LRB',0,'C');
				$this->Cell(40,$this->cellheight ,$row['amount'] . ' ' . $row['direction'],'LRB',1,'R');
				$this->AddFooter();
				$this->AddNewPage();				
				$this->tableHeader();	
				$this->rowcount = 0;
			}
			else{
				$this->Cell(30,$this->cellheight ,$row['date'],'LR',0,'L',0);
				$this->Cell(90,$this->cellheight ,$row['description'],'LR',0,'L');
				$this->Cell(10,$this->cellheight ,$row['currency'],'LR',0,'C');
				$this->Cell(40,$this->cellheight ,$row['amount'] . ' ' . $row['direction'],'LR',1,'R');
			}

			$this->rowcount ++;
		}
		
		$this->writeFalse($this->rowcount);

		if(isset($List['total'])){
			$this->Cell(130,$this->cellheight ,' Total',1,0,'R',1);
			$this->Cell(40,$this->cellheight ,App::Component('Accounts')->Helper('Data')->numberformate($List['total']),1,1,'R',1);
		}
		else{
			$this->Cell(170,$this->cellheight ,'','T',1,'R',0);
		}
	
		$this->AddFooter();

		$this->Output("Statement_".date('Y-m-d').".pdf","D"); 
		exit;		
	}
	
	public function tableHeader(){
		$this->Cell(30,$this->cellheight ,'Date',1,0,'L',1);
		$this->Cell(90,$this->cellheight ,"Description",1,0,'L',1);
		$this->Cell(10,$this->cellheight ,'Curr',1,0,'C',1);
		$this->Cell(40,$this->cellheight ,'Amount',1,1,'R',1);
	}
	
	public function writeFalse($cnt=0){
		for(;$cnt<35;$cnt++){
				$this->Cell(30,$this->cellheight ,' ','LR',0,'L',0);
				$this->Cell(90,$this->cellheight ,' ','LR',0,'L');
				$this->Cell(10,$this->cellheight ,' ','LR',0,'C');
				$this->Cell(40,$this->cellheight ,' ','LR',1,'R');
		}
	}
	
	private function AddFooter(){
		$this->setY(-30);
		$this->Cell(170,$this->cellheight ,' ','B',1,'L',0);
	
		$this->Cell(170,$this->cellheight ,
			App::Config()->Setting('site_title') . ', '. 
			App::Config()->Setting('admin_email')  . ', '. 
			App::Config()->Setting('copy_right_text')
		,$this->border,1,'L',0);

	}
	private function AddNewPage($isInner = false){
	
		$this->SetTopMargin(0);
		$this->SetLeftMargin(0);
		$this->SetAutoPageBreak(0);
		$this->AddPage("p");		
		$this->SetTextColor(255, 255, 255);	
		$this->SetFillColor(79,198,221);
		$this->SetFont($this->fontFamily,'B',15); 
		if($isInner){
			$this->Cell(220,20 ,$this->Title($this->getStatementType()) ,$this->b,1,'C',1); 
		}
		else{
			$this->Cell(220,20 ,$this->Title($this->getStatementType()) ,$this->b,1,'C',1); 
		}
		$this->SetFont($this->fontFamily,null,10); 
		
		$this->SetTextColor(0, 0, 0);	
		$this->Ln(10);
		$this->SetTopMargin(10);
		$this->SetLeftMargin(20);	
	}
}